# 📝 Exercise 02 – Fill in the Blanks: Tecnología e Inteligencia Artificial

**Instrucciones:** Elige la palabra correcta para cada espacio en blanco.  
Tiempo sugerido: **8 minutos**

---

## Texto: The Rise of Artificial Intelligence

Artificial intelligence (AI) has [1] ______ one of the most transformative technologies of the 21st century.
Many experts have [2] ______ concerns about the ethical implications of AI systems,
particularly regarding privacy and the potential for job [3] ______.
Despite these concerns, AI continues to [4] ______ rapid advancements in fields
such as healthcare, education, and finance.
For example, AI-powered tools are now [5] ______ used to diagnose diseases
with a level of accuracy that [6] ______ human specialists in some cases.
However, critics argue that the technology still [7] ______ significant limitations
and should not be [8] ______ as a replacement for human judgment.

---

## Preguntas

**[1]** Choose the correct verb form (present perfect):

- A) become
- B) became
- C) becoming
- D) becomes

---

**[2]** Select the correct collocation:

- A) risen
- B) raised
- C) rose
- D) raising

---

**[3]** Choose the correct noun form:

- A) displace
- B) displaced
- C) displacement
- D) displacing

---

**[4]** Select the correct verb:

- A) make
- B) experience
- C) do
- D) perform

---

**[5]** Choose the correct adverb:

- A) wide
- B) widely
- C) widen
- D) wideness

---

**[6]** Select the correct verb:

- A) surpasses
- B) surpass
- C) surpassing
- D) surpassed

---

**[7]** Choose the correct verb:

- A) have
- B) has
- C) having
- D) had

---

**[8]** Select the correct collocation:

- A) regarded
- B) seen
- C) viewed
- D) considered

> 💡 Hint: "should not be ______ as" → think about which verb collocates with "as" in academic English.

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 02

---

## 📌 Vocabulario Clave

| Palabra | Tipo | Sinónimo académico |
|---------|------|--------------------|
| transformative | adjetivo | revolutionary, groundbreaking |
| implications | sustantivo | consequences, effects |
| advancements | sustantivo | progress, development |
| diagnose | verbo | identify, detect |
| accuracy | sustantivo | precision |
| judgment | sustantivo | decision-making, assessment |
