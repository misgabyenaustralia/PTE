# 📝 Exercise 03 – Fill in the Blanks: Salud y Ciencia

**Instrucciones:** Elige la palabra correcta para cada espacio en blanco.  
Tiempo sugerido: **8 minutos**

---

## Texto: The Importance of Sleep for Cognitive Function

Sleep is [1] ______ to maintaining good cognitive function and overall health.
Recent studies have [2] ______ that adults who sleep fewer than six hours per night
are significantly more [3] ______ to experience memory problems and reduced concentration.
The brain uses sleep to [4] ______ memories and remove toxic waste products
that [5] ______ during the day.
Sleep deprivation has also been [6] ______ with a higher risk of developing
chronic conditions such as obesity, diabetes, and cardiovascular disease.
Health professionals [7] ______ that adults aim for seven to nine hours of sleep per night
and that they [8] ______ a consistent sleep schedule to support their body's natural rhythm.

---

## Preguntas

**[1]** Choose the correct adjective:

- A) essential
- B) essentially
- C) essence
- D) essentials

---

**[2]** Select the correct collocation:

- A) shown
- B) told
- C) said
- D) informed

---

**[3]** Choose the correct adjective form:

- A) probable
- B) likely
- C) possibly
- D) maybe

---

**[4]** Select the correct verb:

- A) consolidate
- B) consolidation
- C) consolidated
- D) consolidating

---

**[5]** Choose the correct verb:

- A) build up
- B) builds up
- C) built up
- D) building up

---

**[6]** Select the correct passive structure:

- A) linked
- B) connecting
- C) associating
- D) relating

---

**[7]** Choose the correct verb for giving advice/recommendation:

- A) tell
- B) recommend
- C) say
- D) speak

---

**[8]** Select the correct verb:

- A) keep
- B) maintain
- C) make
- D) do

> 💡 Hint: Which verb collocates with "a consistent schedule"?

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 03

---

## 📌 Vocabulario Clave

| Palabra | Tipo | Significado |
|---------|------|------------|
| cognitive | adjetivo | relating to mental processes |
| concentration | sustantivo | ability to focus |
| sleep deprivation | frase | lack of sleep |
| chronic | adjetivo | long-lasting |
| cardiovascular | adjetivo | relating to the heart |
| consistent | adjetivo | regular, unchanging |
| rhythm | sustantivo | regular pattern |
