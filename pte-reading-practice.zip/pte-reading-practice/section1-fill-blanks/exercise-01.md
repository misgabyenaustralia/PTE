# 📝 Exercise 01 – Fill in the Blanks: Medio Ambiente

**Instrucciones:** Elige la palabra correcta para cada espacio en blanco.  
Tiempo sugerido: **8 minutos**

---

## Texto: Deforestation and Its Consequences

Deforestation is one of the most serious environmental issues [1] ______ the world today.
Every year, millions of hectares of forest are [2] ______ to make way for agriculture and urban development.
Scientists have [3] ______ that the loss of forests has a direct impact on biodiversity,
as many species [4] ______ on these ecosystems for their survival.
Furthermore, trees play a crucial role in [5] ______ carbon dioxide from the atmosphere,
which means that deforestation [6] ______ significantly to global warming.
Governments around the world are being urged to [7] ______ stronger policies
to protect remaining forests and [8] ______ reforestation efforts.

---

## Preguntas

**[1]** The word that best fits the context is:

- A) faced
- B) facing
- C) faces
- D) to face

---

**[2]** Choose the correct form:

- A) cleared
- B) clearing
- C) clear
- D) to clear

---

**[3]** Select the correct collocation:

- A) told
- B) said
- C) warned
- D) spoken

---

**[4]** Choose the correct verb form:

- A) depend
- B) depends
- C) depending
- D) are depending

---

**[5]** Select the correct verb:

- A) absorb
- B) absorbing
- C) absorbed
- D) absorption

---

**[6]** Choose the correct verb + adverb:

- A) contributes
- B) contribute
- C) contributing
- D) contributed

---

**[7]** Select the correct collocation with "policies":

- A) make
- B) do
- C) implement
- D) perform

---

**[8]** Choose the correct collocation:

- A) support
- B) make
- C) do
- D) give

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 01

---

## 📌 Vocabulario del Texto

| Palabra | Tipo | Significado |
|---------|------|------------|
| deforestation | sustantivo | deforestación |
| hectares | sustantivo | hectáreas |
| biodiversity | sustantivo | biodiversidad |
| ecosystem | sustantivo | ecosistema |
| crucial | adjetivo | crucial, fundamental |
| reforestation | sustantivo | reforestación |
| carbon dioxide | sustantivo | dióxido de carbono |
