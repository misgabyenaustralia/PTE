# 📝 Exercise 03 – Multiple Choice: Cambio Climático

**Instrucciones:** Lee el texto y selecciona **todas las opciones que sean verdaderas** según el texto.  
⚠️ Las respuestas incorrectas restan puntos.  
Tiempo sugerido: **5 minutos**

---

## Texto

Climate change represents one of the most pressing challenges of the contemporary era, with scientific consensus firmly establishing that rising global temperatures are primarily driven by human-induced greenhouse gas emissions. The burning of fossil fuels — including coal, oil, and natural gas — accounts for the largest share of these emissions globally, though deforestation and agricultural practices also contribute substantially.

The consequences of unchecked climate change are projected to be wide-ranging and severe. Rising sea levels threaten to inundate low-lying coastal regions, displacing millions of people in countries such as Bangladesh and several Pacific island nations. Meanwhile, more frequent and intense weather events — including droughts, floods, and hurricanes — are expected to place unprecedented pressure on food and water security worldwide.

International efforts to address climate change have intensified in recent years, most notably through the Paris Agreement, under which signatory nations committed to limiting global warming to well below 2°C above pre-industrial levels. Nevertheless, critics have pointed out that the voluntary nature of these commitments means that compliance cannot be enforced, and several major economies continue to fall short of their stated targets.

---

## Pregunta

¿Cuáles de las siguientes afirmaciones son **verdaderas** según el texto?  
*(Selecciona todas las correctas)*

- **A)** La quema de combustibles fósiles es la principal fuente de emisiones de gases de efecto invernadero.
- **B)** La deforestación y la agricultura no tienen ningún efecto en el cambio climático.
- **C)** El aumento del nivel del mar podría desplazar a millones de personas en zonas costeras.
- **D)** El Acuerdo de París exige que los países limiten el calentamiento a menos de 2°C.
- **E)** Todos los países firmantes del Acuerdo de París cumplen sus compromisos climáticos.
- **F)** Los compromisos del Acuerdo de París son de carácter voluntario.
- **G)** Las sequías y las inundaciones se volverán más frecuentes e intensas según las proyecciones.

---

## 📌 Pregunta Adicional (Nivel Avanzado)

Basándote SOLO en el texto, ¿cuál es la idea principal del tercer párrafo?

- **A)** El Acuerdo de París ha sido un éxito completo en reducir las emisiones globales.
- **B)** Los esfuerzos internacionales para combatir el cambio climático tienen limitaciones en su cumplimiento.
- **C)** Los países en desarrollo son los principales responsables del incumplimiento climático.
- **D)** El calentamiento global ya supera los 2°C sobre los niveles preindustriales.

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 03 (Multiple Choice)

---

## 📌 Vocabulario del Texto

| Palabra | Significado |
|---------|------------|
| pressing | urgente |
| consensus | consenso |
| greenhouse gas | gas de efecto invernadero |
| unchecked | sin control |
| inundate | inundar |
| unprecedented | sin precedentes |
| signatory | signatario (que firma un acuerdo) |
| compliance | cumplimiento |
