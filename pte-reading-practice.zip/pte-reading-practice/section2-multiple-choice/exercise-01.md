# 📝 Exercise 01 – Multiple Choice: Vehículos Eléctricos

**Instrucciones:** Lee el texto y selecciona **todas las opciones que sean verdaderas** según el texto.  
⚠️ Las respuestas incorrectas restan puntos. Solo marca lo que puedas confirmar con el texto.  
Tiempo sugerido: **5 minutos**

---

## Texto

The widespread adoption of electric vehicles (EVs) represents one of the most significant shifts in the transportation sector in recent decades. Governments across Europe, North America, and Asia have introduced a variety of financial incentives to encourage consumers to switch from conventional petrol-powered cars to electric alternatives. These measures include tax credits, reduced registration fees, and subsidies for home charging equipment.

Despite this momentum, several challenges continue to hinder the mass adoption of EVs. The high upfront cost of electric vehicles remains a barrier for many consumers, particularly in lower-income households. Additionally, the availability of public charging infrastructure is still limited in rural and regional areas, making long-distance travel difficult for EV owners.

Environmental advocates point out that while EVs produce zero direct emissions, the electricity used to charge them is frequently generated from fossil fuels, which offsets some of the environmental benefits. Furthermore, the extraction of lithium and cobalt — key materials in EV batteries — has been associated with significant ecological damage and human rights concerns in certain mining regions.

---

## Pregunta

¿Cuáles de las siguientes afirmaciones son **verdaderas** según el texto?  
*(Selecciona todas las correctas)*

- **A)** Los gobiernos de múltiples regiones del mundo ofrecen incentivos financieros para la compra de EVs.
- **B)** El costo inicial elevado de los EVs es un obstáculo para muchos compradores.
- **C)** La infraestructura de carga eléctrica está bien desarrollada en todas las áreas rurales.
- **D)** Los vehículos eléctricos producen cero emisiones directas.
- **E)** La electricidad utilizada para cargar los EVs siempre proviene de fuentes renovables.
- **F)** La minería de litio y cobalto tiene impactos negativos documentados.
- **G)** Los EVs son actualmente más baratos que los autos a gasolina para todos los consumidores.

---

## 📌 Análisis Guiado (para después de responder)

Antes de ver las respuestas, reflexiona:

1. ¿Cuáles opciones usaron palabras absolutas como "siempre", "todas", "todos"?
2. ¿Qué opciones contradicen directamente algo que dice el texto?
3. ¿Qué opciones mencionan algo que el texto **no menciona para nada**?

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 01 (Multiple Choice)

---

## 📌 Vocabulario del Texto

| Palabra | Significado |
|---------|------------|
| widespread adoption | adopción masiva / generalizada |
| incentives | incentivos |
| subsidies | subsidios |
| hinder | dificultar, obstaculizar |
| upfront cost | costo inicial |
| offset | compensar, neutralizar |
| extraction | extracción |
| ecological damage | daño ecológico |
