# 📝 Exercise 02 – Multiple Choice: Inteligencia Artificial

**Instrucciones:** Lee el texto y selecciona **todas las opciones que sean verdaderas** según el texto.  
⚠️ Las respuestas incorrectas restan puntos.  
Tiempo sugerido: **5 minutos**

---

## Texto

Artificial intelligence (AI) is rapidly transforming industries ranging from healthcare and education to finance and manufacturing. In the medical sector, AI algorithms have demonstrated the ability to detect certain cancers and eye diseases with a level of accuracy comparable to — and in some cases exceeding — that of trained specialists. This has led to growing enthusiasm among health administrators for the integration of AI tools into diagnostic workflows.

However, the integration of AI into healthcare is not without its critics. Some medical professionals argue that over-reliance on AI systems could lead to a reduction in the critical thinking skills of junior doctors, who may become accustomed to following algorithmic recommendations rather than developing their own diagnostic reasoning. There are also significant concerns about data privacy, as AI systems require access to large volumes of sensitive patient information to function effectively.

Moreover, access to AI-powered healthcare tools remains highly unequal globally. While wealthy nations have begun incorporating these technologies into their public health systems, many developing countries lack the infrastructure, funding, and technical expertise necessary to benefit from these advances. This disparity risks widening existing health inequalities rather than reducing them.

---

## Pregunta

¿Cuáles de las siguientes afirmaciones son **verdaderas** según el texto?  
*(Selecciona todas las correctas)*

- **A)** La IA puede detectar enfermedades con un nivel de precisión comparable al de especialistas humanos.
- **B)** Todos los médicos apoyan el uso de IA en el diagnóstico clínico.
- **C)** Existe preocupación de que la IA reduzca el pensamiento crítico en médicos jóvenes.
- **D)** Los sistemas de IA no requieren acceso a datos personales de los pacientes.
- **E)** El acceso a herramientas de IA en salud es desigual entre países ricos y pobres.
- **F)** Los países en desarrollo ya tienen la infraestructura para implementar IA en salud.
- **G)** Las desigualdades en el acceso a IA podrían aumentar las brechas de salud existentes.

---

## 📌 Análisis Guiado

Para cada opción que marques como incorrecta, escribe aquí qué parte del texto la contradice o la ignora:

| Opción | ¿Por qué es incorrecta? |
|--------|------------------------|
| | |
| | |

---

## ✅ Respuestas

Ver `../../answer-keys/all-answers.md` → Sección: Exercise 02 (Multiple Choice)

---

## 📌 Vocabulario del Texto

| Palabra | Significado |
|---------|------------|
| algorithms | algoritmos |
| diagnostic workflows | flujos de trabajo diagnóstico |
| over-reliance | dependencia excesiva |
| algorithmic recommendations | recomendaciones del algoritmo |
| disparity | disparidad, desigualdad |
| infrastructure | infraestructura |
| expertise | conocimiento especializado |
